<?php
session_start();
require_once 'connect.php';
$usuario = $_SESSION['username'];
//$usuario = "jose renovato ";

$id = $_GET['id'];
$sel="SELECT id_ticket,email, telefono, sucursal,categoria, descripcion, f_cierre FROM tickets WHERE id_ticket = '$id'";
$res=mysqli_query($conexion,$sel);
$mos = mysqli_fetch_row($res);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <?php require_once("../MainHead/head.php");?>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="1.css">
    <title>Modificar Registro</title>
</head>

<body>

    <style>
        .bg-pri {
            background-color: #07282C;
            color: #fff;
        }

        .bg-base {
            background-color: #07282C;
            color: #fff;
        }

        .bg-base:hover {
            background-color: #0a565f;
            color: #fff;
        }

        .color-base {
            color: #07282C !important;
        }

        .bg-slave {
            background-color: #D9D9D9;
            color: #07282C;
        }

        .bg-slave:hover {
            background-color: #D9D9D9;
            color: #07282C;
        }

        .box-sha {
            box-shadow: 2px 3px 7px #b1b1b1;
        }

        .w200px {
            width: 200px;
        }
    </style>

    <header>
        <!-- navegacion -->
        <nav class="navbar navbar-expand-sm bg-pri fixed-top">
            <div class="container-fluid px-5">
                <a class="navbar-brand fs-3 fw-bold" href="#">CCIMAIT</a>
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link fw-bold text-white" href="#">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link fw-bold text-white" href="#">Quienes Somos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link fw-bold text-white" href="#">Servicios</a>
                    </li>
                    <li class="nav-item dropdown">
                        <!-- Boton de usuario -->
                        <a class="nav-link fw-bold text-white dropdown-toggle" href="#" role="button"
                            data-bs-toggle="dropdown">
                            <?php
              if(!isset($usuario)){
                header("location: login.php");
              }else{
                echo "$usuario";             
                echo "";
              }
            ?></a>

                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="#">Perfil</a></li>
                            <li><a class="dropdown-item" href='php/cerrar_sesion.php'>Salir</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </nav>
        <!-- fin de Navegacion -->
    </header>
    <?php 
switch($usuario){
	case 'Yaressi Rodriguez':
		case 'Jimena Alarcon':
            ?>

    <div class="page-content">
        <div class="container">
            <div class="row justify-content-center align-content-center">
                <div class="col-7 card p-0 box-sha">
                    <div class="bg-pri p-3">
                        <h3 class="text-center text-white">Modificar registro</h3>
                    </div>
                    <form action="edit2.php" method="post" class="p-4">
                        <input type="hidden" class="form-control" name="id" id="id" aria-describedby="emailHelpId"
                            value="<?php echo $mos[0] ?>" required>
                        <div class="mb-3">
                            <label for="" class="form-label">Reasignar</label>
                            <select class="form-select form-select-lg" name="reasignar" id="reasignar">
                                <option value="Jimena Alarcon">Jimena Alarcon</option>
                                <option value="Jose Renovato">Jose Renovato</option>
                                <option value="Juan Lira">Juan Lira</option>
                                <option value="Yaressi Rodriguez">Yaressi Rodriguez</option>
                                <option value="Manuel Olvera">Manuel Olvera</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">Estado</label>
                            <select class="form-select form-select-lg" name="estado" id="estado">
                                <option value="Abierto">Abierto</option>
                                <option value="Cerrado">Cerrado</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">Fecha de cierre</label>
                            <input type="text" class="form-control" name="fecha" id="fecha" aria-describedby="helpId"
                                value="<?php echo $mos[6] ?>">
                        </div>
                        <div class="pt-3 d-flex justify-content-end ">
                            <button type="button" class="btn bg-slave color-base deletedbt w200px"
                                data-bs-toggle="modal" data-bs-target="#del">
                                <a class="color-base"
                                    href="http://localhost/proyecto/tickets/view/ConsultarTicket/">Cancelar</a>
                            </button>
                            <button type="submit" class="ms-2 btn bg-base editbtn w200px">
                                Enviar
                            </button>

                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <?php
            break;
			case 'jose renovato':?>

    <div class="page-content">
        <div class="container">
            <div class="row justify-content-center align-content-center">
                <div class="col-7 card p-0 box-sha">
                    <div class="bg-pri p-3">
                        <h3 class=" text-center text-white">Modificar registro</h3>
                    </div>
                    <form action="edit1.php" method="post" class="p-4">
                        <input type="hidden" class="form-control" name="id" id="id" aria-describedby="emailHelpId"
                            value="<?php echo $mos[0] ?>" required>
                        <div class="mb-3">
                            <label for="" class="form-label">Reasignar</label>
                            <select class="form-select form-select-lg" name="reasignar" id="reasignar">
                                <option value="Jose Renovato">Jose Renovato</option>
                                <option value="Juan Lira">Juan Lira</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">Estado</label>
                            <select class="form-select form-select-lg" name="estado" id="estado">
                                <option value="Abierto">Abierto</option>
                                <option value="Cerrado">Cerrado</option>
                            </select>
                        </div>
                        <div class="pt-3 d-flex justify-content-end">
                            <button type="button" class="btn bg-slave color-base deletedbt w200px" data-bs-toggle="modal"
                                data-bs-target="#del">
                                <a class="color-base" href="http://localhost/proyecto/tickets/view/ConsultarTicket/">Cancelar</a>
                            </button>
                            <button type="submit" class="btn bg-base editbtn w200px">
                                Enviar
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <?php
        break;
        case 'manuel olvera':
            ?>

    <div class="page-content">
        <div class="container">
            <div class="row justify-content-center align-content-center">
                <div class="col-7 card p-0 box-sha">
                    <div class="bg-pri p-3">
                        <h3 class="text-center text-white">Modificar registro</h3>
                    </div>
                    <form action="edit1.php" method="post" class="p-4">
                        <input type="hidden" class="form-control" name="id" id="id" aria-describedby="emailHelpId"
                            value="<?php echo $mos[0] ?>" required>
                        <div class="mb-3">
                            <label for="" class="form-label">Reasignar</label>
                            <select class="form-select form-select-lg" name="reasignar" id="reasignar">
                                <option value="Manuel Olvera">Manuel Olvera</option>
                                <option value="Alejandro Cabello">Alejandro Cabello</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">Estado</label>
                            <select class="form-select form-select-lg" name="estado" id="estado">
                                <option value="Abierto">Abierto</option>
                                <option value="Cerrado">Cerrado</option>
                            </select>
                        </div>
                        <div class="pt-3 d-flex justify-content-end ">
                            <button type="button" class="btn bg-slave color-base deletedbt w200px"
                                data-bs-toggle="modal" data-bs-target="#del">
                                <a class="color-base"
                                    href="http://localhost/proyecto/tickets/view/ConsultarTicket/">Cancelar</a>
                            </button>
                            <button type="submit" class="btn bg-base editbtn w200px">
                                Enviar
                            </button>

                        </div>
                    </form>

                </div>
            </div>
        </div>
    </div>
    <?php
            break;
					case 'juan lira':
						case 'alejandro cabello':
                            ?>

    <div class="page-content">
        <div class="container">
            <div class="row justify-content-center align-content-center">
                <div class="col-7 card p-0 box-sha">
                    <div class="bg-pri p-3">
                        <h3 class="text-center text-white">Modificar registro</h3>
                    </div>
                    <form action="edit1.php" method="post" class="p-4">
                        <input type="hidden" class="form-control" name="id" id="id" aria-describedby="emailHelpId"
                            value="<?php echo $mos[0] ?>" required>
                        <div class="mb-3">
                            <label for="" class="form-label">Estado</label>
                            <select class="form-select form-select-lg" name="estado" id="estado">
                                <option value="Abierto">Abierto</option>
                                <option value="Cerrado">Cerrado</option>
                            </select>
                        </div>

                        <div class="">
                            <button type="button" class="btn bg-slave color-base deletedbt w200px"
                                data-bs-toggle="modal" data-bs-target="#del">
                                <a class="color-base"
                                    href="http://localhost/proyecto/tickets/view/ConsultarTicket/">Cancelar</a>
                            </button>
                            <button type="submit" class="btn bg-base editbtn w200px">
                                Enviar
                            </button>

                        </div>
                    </form>

                </div>
            </div>
        </div>
    </div>

    <?php
        break;
	
	default:

	?>


    <div class="page-content">
        <div class="container">
            <div class="row">
                <div class="col-7">
                    <div class="bg-pri p-3">
                        <h3 class="text-center text-white">Modificar registro</h3>
                    </div>
                    <form action="edit.php" method="post" enctype="multipart/form-data" class="p-4">
                        <input type="hidden" class="form-control" name="id" id="id" aria-describedby="emailHelpId"
                            value="<?php echo $mos[0] ?>" required>

                        <div class="mb-3">
                            <label for="" class="form-label">Email</label>
                            <input type="email" class="form-control" name="email" id="email"
                                aria-describedby="emailHelpId" value="<?php echo $mos[1] ?>" required>
                        </div>

                        <div class="mb-3">
                            <label for="" class="form-label">Telefono</label>
                            <input type="text" class="form-control" name="telefono" id="telefono"
                                aria-describedby="helpId" value="<?php echo $mos[2] ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-label">Sucursal</label>
                            <select class="form-select form-select" name="sucursal" id="sucursal"
                                value="<?php echo $mos[3] ?>">
                                <option selected>Select one</option>
                                <option value="Santa Rosa">Santa Rosa</option>
                                <option value="Bernardo Quintana">Bernardo Quintana</option>
                            </select>
                        </div>

                        <div class="mb-3">
                            <label for="" class="form-label">Categoria</label>
                            <select class="form-select form-select" name="categoria" id="categoria" required
                                value="<?php echo $mos[4] ?>">
                                <option selected>Select one</option>
                                <?php
                        $selectinven="SELECT * FROM categorias WHERE 1";
                        $result=mysqli_query($conexion,$selectinven);
                        while($mostrar=mysqli_fetch_row($result)){?>
                                <option value="<?php echo $mostrar[1] ?>"> <?php echo $mostrar[1] ?> </option>
                                <?php
                        }
                        ?>
                            </select>
                        </div>
                        <div class="mb-3" id="subcategoria">

                        </div>

                        <div class="mb-3">
                            <label for="" class="form-label">Descripcion</label>
                            <input type="text" class="form-control" name="descripcion" id="descripcion" rows="5"
                                required value="<?php echo $mos[5] ?>"></input>
                        </div>

                        <div class="mb-3">
                            <label for="" class="form-label">Elige tu archivo evidencia</label>
                            <input type="file" class="form-control" name="archivo" id="archivo" placeholder=""
                                aria-describedby="fileHelpId">
                        </div>
                        <div class="">
                            <button type="button" class="btn bg-slave color-base  deletedbt w200px" data-bs-toggle="modal"
                                data-bs-target="#del">
                                <a class="color-base" href="http://localhost/proyecto/tickets/view/Home/index.php">Cancelar</a>
                            </button>
                            <button type="submit" class="btn bg-base editbtn w200px">
                                Enviar
                            </button>

                        </div>
                    </form>
                </div>
            </div>


        </div>
    </div>
    <?php
		break;
}
    ?>
</body>

</html>
<script type="text/javascript">
    $(document).ready(function () {
        $('#categoria').val(1);
        recargarLista();

        $('#categoria').change(function () {
            recargarLista();
        });
    })
</script>
<script type="text/javascript">
    function recargarLista() {
        $.ajax({
            type: "POST",
            url: "datos1.php",
            data: "subcategoria=" + $('#categoria').val(),
            success: function (r) {
                $('#subcategoria').html(r);
            }
        });
    }
</script>