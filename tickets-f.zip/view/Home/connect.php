<?php
    $conexion=mysqli_connect('localhost','root','','tickets_ti');
  //conexion en linea 
  //$conexion=mysqli_connect('localhost','bbbme11_ti','Gccima22.','bbbme11_ti1');
?>