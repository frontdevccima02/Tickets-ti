<?php
session_start();
require_once 'connect.php';
$usuario = $_SESSION['username'];

$id = $_GET['id'];

$insert = "UPDATE `tickets` SET `estatus`='inactivo' WHERE id_ticket = '$id'";

$query = mysqli_query($conexion,$insert);


if ($query) 
{
    echo '<script language="javascript">alert("Los datos han sido eliminados");</script>';
    echo "<script>
    window.location.href = 'http://ti.grupoccima.com/tickets/view/Home/index.php'; </script>"; 
} else {
    echo '<script language="javascript">alert("Algo Salio mal");</script>';
    echo "<script>
    window.location.href = 'http://ti.grupoccima.com/tickets/view/Home/index.php'; </script>";
}
?>