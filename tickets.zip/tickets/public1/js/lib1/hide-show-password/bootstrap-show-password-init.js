$(document).ready(function() {
    $('#hide-show-password').password();
});
