$(document).ready(function() {
    $('.clockpicker').clockpicker({
        autoclose: true,
        donetext: 'Done',
        'default': 'now'
    });
});
